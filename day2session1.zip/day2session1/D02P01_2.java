package com.learning.core.day2session1;
import java.util.Scanner;

public class D02P01_2 {
	

	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        System.out.println("Enter a string:");
	        String inputString = scanner.nextLine();
	        
	        
	        int vowelCount = countVowels(inputString);
	        
	        
	        System.out.println("Enter the expected count of vowels:");
	        int expectedCount = scanner.nextInt();
	        
	        
	        if (vowelCount > expectedCount) {
	            System.out.println("Mismatch in vowels count.");
	        } else {
	            System.out.println("Vowel count matches or is less than expected.");
	        }
	        
	        scanner.close();
	    }
	    
	    // Function to count vowels in a string
	    public static int countVowels(String str) {
	        int count = 0;
	        for (int i = 0; i < str.length(); i++) {
	            char ch = Character.toLowerCase(str.charAt(i));
	            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
	                count++;
	            }
	        }
	        return count;
	    }
	}



