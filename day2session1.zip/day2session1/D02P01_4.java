package com.learning.core.day2session1;

public class D02P01_4 {
	   
	public static int longestPalindromicSubsequence(String str) {
	        int n = str.length();
	        int[][] dp = new int[n][n];
	        
	       
	        for (int i = 0; i < n; i++) {
	            dp[i][i] = 1;
	        }
	        
	        for (int len = 2; len <= n; len++) {
	            for (int i = 0; i < n - len + 1; i++) {
	                int j = i + len - 1;
	                if (str.charAt(i) == str.charAt(j)) {
	                    dp[i][j] = dp[i + 1][j - 1] + 2;
	                } else {
	                    dp[i][j] = Math.max(dp[i + 1][j], dp[i][j - 1]);
	                }
	            }
	        }
	        
	        
	        return dp[0][n - 1];
	    }
	    
	    
	    public static int minDeletionsForPalindrome(String str) {
	        int lpsLength = longestPalindromicSubsequence(str);
	        
	        return str.length() - lpsLength;
	    }
	    
	    public static void main(String[] args) {
	        String str = "AEBCBDA";
	        System.out.println("Minimum deletions required to make '" + str + "' palindrome: " + minDeletionsForPalindrome(str));
	    }
	}

