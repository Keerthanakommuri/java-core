package com.learning.core.day2session1;

public class D02P01_9 {
	
	    
	    public static String replaceSpaces(String s) {
	        StringBuilder sb = new StringBuilder();
	        
	        for (char c : s.toCharArray()) {
	            if (c == ' ') {
	                sb.append("%20");
	            } else {
	                sb.append(c);
	            }
	        }
	        
	        return sb.toString();
	    }
	    
	    public static void main(String[] args) {
	        String input = "Mr john smith";
	        String replacedString = replaceSpaces(input);
	        System.out.println("Original string: " + input);
	        System.out.println("String with spaces replaced: " + replacedString);
	    }
	}



