package com.learning.core.day2session1;
import java.util.*;

public class D02P01_5 {
	

	    
	    public static boolean canFormCircle(String[] words) {
	        
	        Map<Character, List<String>> graph = new HashMap<>();
	        
	        for (String word : words) {
	            char firstChar = word.charAt(0);
	            char lastChar = word.charAt(word.length() - 1);
	            graph.putIfAbsent(firstChar, new ArrayList<>());
	            graph.get(firstChar).add(word);
	            graph.putIfAbsent(lastChar, new ArrayList<>());
	        }
	        

	        char startChar = words[0].charAt(0);
	        Set<String> visited = new HashSet<>();
	        return dfs(graph, visited, startChar, startChar);
	    }
	    
	    private static boolean dfs(Map<Character, List<String>> graph, Set<String> visited, char startChar, char currentChar) {
	        
	        List<String> words = graph.get(currentChar);
	        
	        if (words == null) {
	            return false; 
	        }
	        
	        for (String word : words) {
	            if (!visited.contains(word)) {
	                visited.add(word);
	                char lastChar = word.charAt(word.length() - 1);
	                if (lastChar == startChar && visited.size() == graph.size()) {
	                   
	                    return true;
	                } else if (dfs(graph, visited, startChar, lastChar)) {
	                   
	                    return true;
	                }
	                visited.remove(word);
	            }
	        }
	        
	        return false;
	    }
	    
	    public static void main(String[] args) {
	        String[] words1 = {"abc", "efg", "cde","ghi","ija"};
	        String[] words2 = {"ljk", "kji", "abc", "cba"};
	        
	        System.out.println("Can form circle (words1): " + canFormCircle(words1));
	        System.out.println("Can form circle (words2): " + canFormCircle(words2));
	    }
	}
