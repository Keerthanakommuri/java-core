package com.learning.core.day2session1;
import java.util.HashSet;
import java.util.Set;

public class D02P01_8 {

	public static boolean canSplitIntoFourDistinctStrings(String s) {
	        // Check if the length of the string is divisible by 4
	        if (s.length() % 4 != 0) {
	            return false;
	        }

	        // Create a set to store characters
	        Set<Character> charSet = new HashSet<>();

	        // Iterate over the string and populate the set
	        for (char c : s.toCharArray()) {
	            if (!charSet.add(c)) {
	                // If any character repeats, return false
	                return false;
	            }
	        }

	        // Check if the size of the set is divisible by 4
	        // If true, it means each character occurs exactly once
	        return charSet.size() % 4 == 0;
	    }

	    public static void main(String[] args) {
	        String input = "aaabb";
	        System.out.println("Can split into four distinct strings: " + canSplitIntoFourDistinctStrings(input));
	    }
	}


