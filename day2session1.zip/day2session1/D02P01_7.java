package com.learning.core.day2session1;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;

public class D02P01_7 {

	    static class TrieNode {
	        TrieNode[] children;
	        boolean isEndOfWord;

	        TrieNode() {
	            children = new TrieNode[26]; // Assuming only lowercase alphabets
	            isEndOfWord = false;
	        }
	    }

	    static class Trie {
	        TrieNode root;

	        Trie() {
	            root = new TrieNode();
	        }

	        // Insert a word into the Trie
	        void insert(String word) {
	            TrieNode current = root;
	            for (char c : word.toCharArray()) {
	                int index = c - 'a';
	                if (current.children[index] == null) {
	                    current.children[index] = new TrieNode();
	                }
	                current = current.children[index];
	            }
	            current.isEndOfWord = true;
	        }

	        // Search for all words that match the given pattern
	        List<String> searchPattern(String pattern) {
	            List<String> results = new ArrayList<>();
	            searchPattern(root, pattern, "", results);
	            return results;
	        }

	        // Recursive function to search for words matching the pattern
	        void searchPattern(TrieNode node, String pattern, String currentWord, List<String> results) {
	            if (node == null) return;

	            // If we have reached the end of the pattern, check if currentWord is a valid word
	            if (pattern.isEmpty()) {
	                if (node.isEndOfWord) {
	                    results.add(currentWord);
	                }
	                return;
	            }

	            char nextChar = pattern.charAt(0);

	            // If the character is a wildcard '?', try all possible characters
	            if (nextChar == '?') {
	                for (int i = 0; i < 26; i++) {
	                    if (node.children[i] != null) {
	                        searchPattern(node.children[i], pattern.substring(1), currentWord + (char) ('a' + i), results);
	                    }
	                }
	            } else {
	                int index = nextChar - 'a';
	                if (node.children[index] != null) {
	                    searchPattern(node.children[index], pattern.substring(1), currentWord + nextChar, results);
	                }
	            }
	        }
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        List<String> dictionary = new ArrayList<>();

	        // Input dictionary words
	        System.out.println("Enter the dictionary words (one word per line, enter 'done' when finished):");
	        while (true) {
	            String word = scanner.nextLine();
	            if (word.equals("done")) {
	                break;
	            }
	            dictionary.add(word);
	        }

	        Trie trie = new Trie();

	        // Insert words into the Trie
	        for (String word : dictionary) {
	            trie.insert(word);
	        }

	        // Input pattern to search
	        System.out.println("Enter the pattern to search (use '?' as a wildcard):");
	        String pattern = scanner.nextLine();

	        // Search for words matching the pattern
	        List<String> matches = trie.searchPattern(pattern);

	        // Display results
	        if (matches.isEmpty()) {
	            System.out.println("No words found matching the pattern.");
	        } else {
	            System.out.println("Words found matching the pattern:");
	            for (String match : matches) {
	                System.out.println(match);
	            }
	        }

	        scanner.close();
	    }
	}
