package com.learning.core.day2session1;

import java.util.*;
public class D02P01_3 {
	

	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        
	        System.out.println("Enter a string:");
	        String inputString = scanner.nextLine();
	        
	        
	        System.out.println("All subsequences of the string:");
	        printSubsequences(inputString, "");
	        
	        scanner.close();
	    }
	    
	  
	    public static void printSubsequences(String input, String output) {
	       
	        if (input.length() == 0) {
	            System.out.println(output);
	            return;
	        }
	        
	      
	        
	        printSubsequences(input.substring(1), output + input.charAt(0));
	        
	       
	        printSubsequences(input.substring(1), output);
	    }
	}



