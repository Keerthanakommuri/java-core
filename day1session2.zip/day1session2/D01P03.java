package com.learning.core.day1session2;
import java.util.HashMap;
import java.util.Map;

public class D01P03 {

	    public static void main(String[] args) {
	        int[] arr = {7, 10, 5, 3, 4, 3, 5, 6};
	        
	        Map<Integer, Integer> map = new HashMap<>();
	        int repeatingIndex = -1;

	        for (int i = 0; i < arr.length; i++) {
	            if (map.containsKey(arr[i])) {
	                repeatingIndex = map.get(arr[i]);
	                break;
	            } else {
	                map.put(arr[i], i);
	            }
	        }

	        if (repeatingIndex != -1) {
	            System.out.println("Index of first repeating element: " + repeatingIndex);
	        } else {
	            System.out.println("No repeating elements found.");
	        }
	    }
	}




